// Usage: node set-password.js "your new password"
// Rewrites the hash in site-config.js. Re-upload the site afterwards.
const fs = require('fs'), crypto = require('crypto');
const pw = process.argv[2];
if (!pw) { console.error('Usage: node set-password.js "new password"'); process.exit(1); }
const file = __dirname + '/site-config.js';
let src = fs.readFileSync(file, 'utf8');
const salt = (src.match(/salt:\s*'([^']*)'/) || [])[1];
if (salt === undefined) { console.error('Could not find salt in site-config.js'); process.exit(1); }
const hash = crypto.createHash('sha256').update(salt + pw).digest('hex');
src = src.replace(/hash:\s*'[0-9a-f]*'/, `hash: '${hash}'`);
fs.writeFileSync(file, src);
console.log('Password updated. New hash:', hash);
