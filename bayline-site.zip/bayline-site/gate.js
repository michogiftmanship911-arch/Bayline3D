/* Password gate for the Bayline 3D viewer.
   This is a front-end gate: it keeps casual visitors out, it is not server security. */
(function () {
  var C = window.BAYLINE, KEY = 'bayline.access';

  // Pure-JS SHA-256, used when crypto.subtle is unavailable (for example some file:// opens).
  function sha256Fallback(str) {
    var bytes = new TextEncoder().encode(str), primes = [];
    for (var n = 2; primes.length < 64; n++) if (primes.every(function (p) { return n % p; })) primes.push(n);
    var frac = function (x) { return Math.floor((x - Math.floor(x)) * 4294967296) >>> 0; };
    var K = primes.map(function (p) { return frac(Math.cbrt(p)); });
    var H = primes.slice(0, 8).map(function (p) { return frac(Math.sqrt(p)); });
    var l = bytes.length, buf = new Uint8Array(((l + 9 + 63) >> 6) << 6);
    buf.set(bytes); buf[l] = 0x80;
    var dv = new DataView(buf.buffer);
    dv.setUint32(buf.length - 4, (l * 8) >>> 0); dv.setUint32(buf.length - 8, Math.floor(l * 8 / 4294967296));
    var rotr = function (x, n) { return (x >>> n) | (x << (32 - n)); }, w = new Uint32Array(64);
    for (var o = 0; o < buf.length; o += 64) {
      for (var i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
      for (i = 16; i < 64; i++) {
        var s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        var s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (i = 0; i < 64; i++) {
        var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25), ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + K[i] + w[i]) >>> 0;
        var S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22), mj = (a & b) ^ (a & c) ^ (b & c);
        var t2 = (S0 + mj) >>> 0;
        h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
      }
      var v = [a, b, c, d, e, f, g, h];
      for (i = 0; i < 8; i++) H[i] = (H[i] + v[i]) >>> 0;
    }
    return H.map(function (x) { return x.toString(16).padStart(8, '0'); }).join('');
  }

  async function sha256(str) {
    try {
      if (window.crypto && crypto.subtle) {
        var d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
        return Array.from(new Uint8Array(d)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
      }
    } catch (e) { /* fall through */ }
    return sha256Fallback(str);
  }

  function read() { try { return sessionStorage.getItem(KEY) || localStorage.getItem(KEY); } catch (e) { return null; } }
  function isUnlocked() { return read() === C.hash; }

  async function tryUnlock(password, remember) {
    var h = await sha256(C.salt + String(password).trim());
    if (h !== C.hash) return false;
    try { (remember ? localStorage : sessionStorage).setItem(KEY, h); } catch (e) { /* storage blocked: unlock fails below */ }
    return isUnlocked();
  }
  function lock() { try { sessionStorage.removeItem(KEY); localStorage.removeItem(KEY); } catch (e) {} }
  function requireUnlock() {
    if (isUnlocked()) return true;
    document.documentElement.style.visibility = 'hidden';
    location.replace('index.html#locked');
    return false;
  }

  window.BaylineGate = { isUnlocked: isUnlocked, tryUnlock: tryUnlock, lock: lock, requireUnlock: requireUnlock, sha256: sha256 };
})();
