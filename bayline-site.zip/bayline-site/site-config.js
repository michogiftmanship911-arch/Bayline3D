/* Bayline 3D site settings. Edit this file, then re-upload the site.
   Change the password with:  node set-password.js "your new password"  */
window.BAYLINE = {
  brand: 'Bayline 3D',
  ownerName: 'Michael',
  email: 'michaelayen001@gmail.com',

  // SHA-256 of (salt + password). Never put the password itself here.
  salt: 'bayline-3d::',
  hash: '584e8be82b5f203b0e11a638cbd618ae0559d57043dfa2592404330267c3c84c',

  // Shown in the contact list on the home page. Add more rows in the same shape,
  // for example { label: 'WhatsApp', value: '+234 ...', href: 'https://wa.me/234...', note: '...' }
  contacts: [
    {
      label: 'Email',
      value: 'michaelayen001@gmail.com',
      href: 'mailto:michaelayen001@gmail.com',
      note: 'Questions, feedback, and password requests.'
    },
    {
      label: 'Request access',
      value: 'Send a pre-filled access request',
      href: 'mailto:michaelayen001@gmail.com?subject=Bayline%203D%20access%20request&body=Hi%20Michael%2C%0D%0A%0D%0AI%27d%20like%20the%20password%20for%20the%20Bayline%203D%20viewer.%0D%0A%0D%0AName%3A%20%0D%0AOrganisation%20or%20reason%3A%20%0D%0A',
      note: 'Opens your mail app with the details Michael needs.'
    }
  ]
};
